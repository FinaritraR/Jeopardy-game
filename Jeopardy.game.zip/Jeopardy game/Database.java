import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Database {

    // Instance variables

    private int numCategories;
    private int numQuestions;

    private String[] categories;
    private Question[][] questions;

    // Constructor

    private Database(int m, int n) {
	categories = new String[m];
	questions = new Question[m][n];
	numCategories = m;
	numQuestions = n;
    }

    // Access methods

    public String getCategory(int index) {
	// precondition: index >= 0 and index < categories.length
	return categories[index];
    }

    public void setCategory(int index, String category) {
	// precondition: index is valid, category is not null
	categories[index] = category;
    }

    public Question getQuestion(int category, int index) {
	// precondition: both category and index are valid indexes
	return questions[category][index];
    }

    public void setQuestion(int category, int index, Question question) {
	// precondition: both category and index are valid indexes
	questions[category][index] = question;
    }

    public int getNumCategories() {
	return numCategories;
    }

    public int getNumQuestions() {
	return numQuestions;
    }

    // A static method to read questions and return a Database object

    public static Database readQuestions(String name) {

	Database local;
	Scanner sc;

	try {
	    sc = new Scanner(new File(name));
	} catch (FileNotFoundException e) {
	    return null;
	}

	int m, n;

	if (sc.hasNextInt()) {
	    m = sc.nextInt();
	} else {
	    return null;
	}

	if (sc.hasNextInt()) {
	    n = sc.nextInt();
	} else {
	    return null;
	}

	if (sc.hasNextLine()) {
	    sc.nextLine(); // skip new line
	} else {
	    return null;
	}

	local = new Database(m, n);

	for (int i = 0; i < m; i++) {
	    if (sc.hasNextLine()) {
		String category = sc.nextLine();
		local.setCategory(i, category);
	    } else {
		return null;
	    }
	}

	for (int i = 0; i < m; i++) {
	    for (int j = 0; j < n; j++) {
		String response, question;
		if (sc.hasNextLine()) {
		    response = sc.nextLine();
		} else {
		    return null;
		}
		if (sc.hasNextLine()) {
		    question = sc.nextLine();
		} else {
		    return null;
		}
		local.setQuestion(i, j, new Question(response, question));
	    }
	}

	if (sc.hasNext()) {
	    while (sc.hasNext()) {
		System.err.print("pending text:" + sc.nextLine());
	    }
	    return null;
	}

	return local;
    }

}
