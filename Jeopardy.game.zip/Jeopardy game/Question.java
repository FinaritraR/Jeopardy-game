// Stores a pair, question and response

public class Question {
    
    // Instance variables
    
    private String question;
    private String response;
    
    // Constructor
    
    public Question(String response, String question) {
	this.question = question;
	this.response = response;
    }

    // Access methods

    public String getQuestion() {
        return question;
    }

    public String getResponse() {
        return response;
    }

}
