import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.border.Border;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

@SuppressWarnings("serial")

public class Jeopardy extends JFrame implements ActionListener {
    
    private static Border spacer = BorderFactory.createEmptyBorder(7, 7, 7, 7);
    
    // Instance variables
    
    private Database data;
    
    // Remembering the question that was selected
    
    private int selectedCategory;
    private int selectedQuestion;

    // LoadGame will be changing the content of this panel each time a new file is loaded
    
    private JPanel game;
    
    // ActionPerformed will be changing the content of answer and question
        
    private JTextArea answer = new JTextArea("");
    private JTextArea question = new JTextArea("");
    
    // Keeping track of references to these two buttons, so that actionPerformed knows
    // which one was clicked, e.getSource() == reveal || e.getSource() == load
    
    private JButton reveal;
    private JButton load;
    
    // Constructor. Creating the graphics for the application
    
    public Jeopardy(String name) {
	super("Jeopardy");
	
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setBackground(Color.WHITE);
	
	data = Database.readQuestions(name);
	
	if (data == null) {
	    System.err.println("Database not found!");
	    System.exit(1);
	}
	
	game = new JPanel();
	game.setBackground(Color.WHITE);
	
	loadGame();
	
	add(game,BorderLayout.CENTER);

	// Creating a panel to hold the question and answer, as well as the controls
	
	JPanel south = new JPanel();
	south.setLayout(new BorderLayout());
	
	// Creating a panel to hold the labels for question and answer
	
	JPanel display = new JPanel();
	display.setLayout(new GridLayout(2,1));

	answer.setBorder(spacer);
	display.add(answer);
	
	question.setBorder(spacer);
	display.add(question);

	south.add(display,BorderLayout.CENTER);
	
	// Creating a panel to hold two buttons, reveal and load
	
	JPanel controls = new JPanel();
	
	reveal = new JButton("Reveal");
	reveal.addActionListener(this);
	controls.add(reveal);

	load = new JButton("Load");
	load.addActionListener(this);
	controls.add(load);
	
	south.add(controls,BorderLayout.SOUTH);
	
	add(south,BorderLayout.SOUTH);
	
	pack();
	setVisible(true);	
    }
    
    private void load() {
	String name;
	boolean done = false;
	while (!done) {
	    name = JOptionPane.showInputDialog(this, "File name...", "lorem_ipsum.txt");
	    if (name == null) { // User cancelled the operation
		done = true;
	    } else {
		data = Database.readQuestions(name);
		if (data == null) {
		    JOptionPane.showMessageDialog(this, "Error reading file: "+name,"Alert", JOptionPane.ERROR_MESSAGE);
		} else {
		    loadGame();
		    done = true;
		}
	    }
	}
    }
    
    private void loadGame() {
	
	game.removeAll(); // Removing the content of the panel
	
	int m, n;
	
	m = data.getNumCategories();
	n = data.getNumQuestions();

	game.setLayout(new GridLayout(m+1,n)); // +1 for the categories
	
	// Adding labels at the top
	
	for (int i=0; i<m; i++) {
	    JLabel button = new JLabel(data.getCategory(i), JLabel.CENTER);
	    button.setBackground(Color.ORANGE);
	    button.setFont(new Font("Sans Serif", Font.BOLD, 14));
	    button.setOpaque(true);
	    game.add(button);
	}

	int amount=100, increment = 100;	
	
	for (int j=0; j<n; j++) {
	    for (int i=0; i<m; i++) {
		game.add(new JeopardyButton(this, i, j, amount));
	    }
	    amount += increment;
	}
	
	selectedCategory = -1; // sentinel values, means no category selected
	selectedQuestion = -1; // sentinel values, means no question selected
	
	answer.setText("");
	question.setText("");
	
	game.revalidate(); // needs to be invoked because components were removed from the panel...
	
	pack();

    } 
    
    // Implements the logic for the game
    
    @Override
    public void actionPerformed(ActionEvent event) {
	
	if (event.getSource() == reveal) {
	    
	    if (selectedCategory == -1) {
		JOptionPane.showMessageDialog(this, "Select a question!", "Alert", JOptionPane.ERROR_MESSAGE);
	    } else {
		question.setText(data.getQuestion(selectedCategory, selectedQuestion).getQuestion());
	    }
	    
	} else if (event.getSource() == load) {
	    
	    load();
	    
	} else if (event.getSource() instanceof JeopardyButton) {
	    JeopardyButton j = (JeopardyButton) event.getSource(); // safe because of the if test
	    selectedCategory = j.getCategory(); // get coordinates of the button
	    selectedQuestion = j.getQuestion();
	    j.setText("-"); // changing the label
	    j.setEnabled(false); // the object designated by j is no longer clickable
	    answer.setText(data.getQuestion(selectedCategory, selectedQuestion).getResponse());
	    question.setText(""); // hide question
	} else {
	    System.err.println(event); // should never happen...
	}
	
    }
   
    public static void main(String[] args) {
	

	new Jeopardy("lorem_ipsum.txt");
   }
     
}
