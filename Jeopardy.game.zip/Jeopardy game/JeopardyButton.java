import java.awt.event.ActionListener;

import javax.swing.JButton;

@SuppressWarnings("serial")

public class JeopardyButton extends JButton {
    
    // Instance variables to memorize the coordinates (category,question) for this button
    
    private int category;
    private int question;
    
    public JeopardyButton(ActionListener listener, int category, int question, int amount) {
	this.category = category;
	this.question = question;
	
	addActionListener(listener); // The Jeopardy object will be the listener for this button
	
	setText("$"+amount);
    }
    
    // Getters

    public int getCategory() {
	return category;
    }
    
    public int getQuestion() {
	return question;
    }
    
}
